/* 
 * File:   intr_info.h
 * Author: Sammy Guergachi <sguergachi at gmail.com>
 *
 * Created on February 9, 2014, 12:08 PM
 */

#ifndef INTR_INFO_H
#define	INTR_INFO_H


#include <stdio.h>
#include <string.h>

    int get_intr_info();



#endif	/* INTR_INFO_H */

